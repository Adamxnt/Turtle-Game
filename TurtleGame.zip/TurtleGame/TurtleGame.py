import turtle as t
import math as m
import random as r
import winsound as w

wn = t.Screen()
wn.bgcolor("red")
wn.bgpic("Grace_Field_House.png")
wn.tracer(2)

mypen = t.Turtle()
mypen.penup()
mypen.setposition(-300,-300)
mypen.pendown()
mypen.pensize(3)
mypen.speed(0)
for side in range(4):
    mypen.forward(600)
    mypen.left(90)
mypen.hideturtle()

player = t.Turtle()
player.color("blue")
player.shape("triangle")
player.penup()
player.speed(0)
player.setposition(r.randint(-280, 280), r.randint(-280, 280))

player2 = t.Turtle()
player2.color("yellow")
player2.shape("triangle")
player2.penup()
player2.speed(0)
player2.setposition(r.randint(-280, 280), r.randint(-280, 280))

player3 = t.Turtle()
player3.color("green")
player3.shape("triangle")
player3.penup()
player3.speed(0)
player3.setposition(r.randint(-280, 280), r.randint(-280, 280))

player4 = t.Turtle()
player4.color("purple")
player4.shape("triangle")
player4.penup()
player4.speed(0)
player4.setposition(r.randint(-280, 280), r.randint(-280, 280))

score1 = 0
score2 = 0
score3 = 0
score4 = 0

maxGoals = 8
goals = []

for count in range(maxGoals):
    goals.append(t.Turtle())
    goals[count].color("red")
    goals[count].shape("circle")
    goals[count].penup()
    goals[count].speed(0)
    goals[count].setposition(r.randint(-280, 280), r.randint(-280, 280))

speed = 1
 
def turnleft():
    player.left(30)
def turnright():
    player.right(30)
def turnleft2():
    player2.left(30)
def turnright2():
    player2.right(30)
def turnleft3():
    player3.left(30)
def turnright3():
    player3.right(30)
def turnleft4():
    player4.left(30)
def turnright4():
    player4.right(30)
def increasespeed():
    global speed
    speed += 1
    w.PlaySound("flyby-Conor-1500306612.wav", w.SND_ASYNC)
def decreasespeed():
    global speed
    speed -= 1
def isCollision(t1, t2):
    d = m.sqrt(m.pow(t1.xcor()-t2.xcor(),2) + m.pow(t1.ycor()-t2.ycor(),2))
    if d < 20:
        return True
    else:
        return False


t.listen()
t.onkey(turnleft, "a")
t.onkey(turnright, "d")
t.onkey(increasespeed, "w")
t.onkey(decreasespeed, "s")

t.listen()
t.onkey(turnleft2, "Left")
t.onkey(turnright2, "Right")
t.onkey(increasespeed, "Up")
t.onkey(decreasespeed, "Down")

t.listen()
t.onkey(turnleft3, "j")
t.onkey(turnright3, "l")
t.onkey(increasespeed, "i")
t.onkey(decreasespeed, "k")

t.listen()
t.onkey(turnleft4, "4")
t.onkey(turnright4, "6")
t.onkey(increasespeed, "8")
t.onkey(decreasespeed, "5")


while True:
    player.forward(speed)
    player2.forward(speed)
    player3.forward(speed)
    player4.forward(speed)

    if player.xcor() > 290 or player.xcor() < -290:
        player.right(90)

    if player.ycor() > 290 or player.ycor() < -290:
        player.right(90)

    for count in range(maxGoals):
        if goals[count].xcor() > 290 or goals[count].xcor() < -290:
            goals[count].right(90)

        if goals[count].ycor() > 290 or goals[count].ycor() < -290:
            goals[count].right(90)


    for count in range(maxGoals):
        d = m.sqrt(m.pow(player.xcor()-goals[count].xcor(),2) + m.pow(player.ycor()-goals[count].ycor(),2))
        if isCollision(player, goals[count]):
           goals[count].setposition(r.randint(-280, 280), r.randint(-280, 280))
           goals[count].right(r.randint(0, 280))
           score1 += 1
           print("player one", score1)

    for count in range(maxGoals):
        goals[count].forward(3)

    if player2.xcor() > 290 or player2.xcor() < -290:
        player2.right(90)

    if player2.ycor() > 290 or player2.ycor() < -290:
        player2.right(90)

    for count in range(maxGoals):
        d = m.sqrt(m.pow(player2.xcor()-goals[count].xcor(),2) + m.pow(player2.ycor()-goals[count].ycor(),2))
        if isCollision(player2, goals[count]):
           goals[count].setposition(r.randint(-280, 280), r.randint(-280, 280))
           goals[count].right(r.randint(0, 280))
           score2 += 1
           print("player two", score2)

    for count in range(maxGoals):
        d = m.sqrt(m.pow(player3.xcor()-goals[count].xcor(),2) + m.pow(player3.ycor()-goals[count].ycor(),2))
        if isCollision(player3, goals[count]):
           goals[count].setposition(r.randint(-280, 280), r.randint(-280, 280))
           goals[count].right(r.randint(0, 280))
           score3 += 1
           print("player three", score3)

    if player3.xcor() > 290 or player3.xcor() < -290:
        player3.right(90)

    if player3.ycor() > 290 or player3.ycor() < -290:
        player3.right(90)

    if player4.xcor() > 290 or player4.xcor() < -290:
        player4.right(90)

    if player4.ycor() > 290 or player4.ycor() < -290:
        player4.right(90)

    for count in range(maxGoals):
        d = m.sqrt(m.pow(player4.xcor()-goals[count].xcor(),2) + m.pow(player4.ycor()-goals[count].ycor(),2))
        if isCollision(player4, goals[count]):
           goals[count].setposition(r.randint(-280, 280), r.randint(-280, 280))
           goals[count].right(r.randint(0, 280))
           score4 += 1
           print("player four", score4)
    if speed >= 10:
        speed -= 1
    if speed <= -10:
        speed += 1





delay = input("Press Enter to finish")
